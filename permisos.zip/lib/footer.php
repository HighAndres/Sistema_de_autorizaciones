<?php date_default_timezone_set('America/Mexico_City');?>
<link rel="stylesheet" href="../css/estilos.css">
<footer>
        <div class="pie_pagina1"> <span style="font-family:arial;">&reg;</span> Todos los Derechos Reservados
        <p>Dudas o correcciones acudir con Recursos Humanos</p></div>
        <div class="pie_pagina2"> <img src="../img/GpoWalworth_Logo_Negativo-sombra.png" class="img_footer" alt="Grupo Walworth"> </div>
        <div class="pie_pagina3"> &copy; Grupo Walworth <?php echo date('Y'); ?></div>
</footer>